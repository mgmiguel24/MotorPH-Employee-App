import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EmployeeManagerGUI {
    private static List<String[]> employeeList = new ArrayList<>();
    private static DefaultTableModel tableModel;

    private static final String[] COLUMN_NAMES = {
        "Emp #", "Last Name", "First Name", "Birthday", "Address", "Phone Number",
        "SSS #", "Philhealth #", "TIN #", "Pag-ibig #", "Status", "Position",
        "Immediate Supervisor", "Basic Salary", "Rice Subsidy", "Phone Allowance",
        "Clothing Allowance", "Gross Semi-monthly", "Hourly Rate"
    };

    private static final String CSV_PATH = "/Users/mikeegutierrezmiguel/MOTORPH DATA FILES/MotorPH Employee Data - Employee Details.csv";

    public static void main(String[] args) {
        JFrame frame = new JFrame("MotorPH Employee Records");
        frame.setSize(1300, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        tableModel = new DefaultTableModel(COLUMN_NAMES, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 1240, 350);

        loadCSVData();

        JButton viewBtn = new JButton("View");
        viewBtn.setBounds(20, 390, 100, 30);
        viewBtn.addActionListener(e -> viewEmployee(table));

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(140, 390, 100, 30);
        addBtn.addActionListener(e -> showEmployeeDialog(frame, null, -1));

        JButton updateBtn = new JButton("Update");
        updateBtn.setBounds(260, 390, 100, 30);
        updateBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                showEmployeeDialog(frame, employeeList.get(row), row);
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a row to update.");
            }
        });

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(380, 390, 100, 30);
        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure to delete?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    employeeList.remove(row);
                    tableModel.removeRow(row);
                    saveCSVData();
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a row to delete.");
            }
        });

        frame.add(scrollPane);
        frame.add(viewBtn);
        frame.add(addBtn);
        frame.add(updateBtn);
        frame.add(deleteBtn);
        frame.setVisible(true);
    }

    private static void viewEmployee(JTable table) {
        int row = table.getSelectedRow();
        if (row >= 0) {
            StringBuilder details = new StringBuilder();
            for (int i = 0; i < COLUMN_NAMES.length; i++) {
                details.append(COLUMN_NAMES[i]).append(": ").append(employeeList.get(row)[i]).append("\n");
            }
            JOptionPane.showMessageDialog(null, details.toString(), "Employee Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Select a row first.");
        }
    }

    private static void showEmployeeDialog(JFrame parent, String[] existingData, int rowIndex) {
        JTextField[] fields = new JTextField[COLUMN_NAMES.length];
        JPanel panel = new JPanel(new java.awt.GridLayout(0, 2));

        for (int i = 0; i < COLUMN_NAMES.length; i++) {
            panel.add(new JLabel(COLUMN_NAMES[i] + ":"));
            fields[i] = new JTextField(existingData != null ? existingData[i] : "");
            panel.add(fields[i]);
        }

        int result = JOptionPane.showConfirmDialog(parent, panel, (rowIndex >= 0 ? "Update" : "Add") + " Employee",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String[] newEmp = new String[COLUMN_NAMES.length];
            for (int i = 0; i < COLUMN_NAMES.length; i++) {
                newEmp[i] = fields[i].getText().trim();
            }

            if (rowIndex >= 0) {
                employeeList.set(rowIndex, newEmp);
                for (int i = 0; i < COLUMN_NAMES.length; i++) {
                    tableModel.setValueAt(newEmp[i], rowIndex, i);
                }
            } else {
                employeeList.add(newEmp);
                tableModel.addRow(newEmp);
            }
            saveCSVData();
        }
    }

    private static void loadCSVData() {
        employeeList.clear();
        tableModel.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader(CSV_PATH))) {
            String line;
            br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                String[] row = line.split(",", -1);
                if (row.length >= COLUMN_NAMES.length) {
                    employeeList.add(row);
                    tableModel.addRow(row);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading CSV: " + e.getMessage());
        }
    }

    private static void saveCSVData() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(CSV_PATH))) {
            pw.println(String.join(",", COLUMN_NAMES));
            for (String[] emp : employeeList) {
                pw.println(String.join(",", emp));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving CSV: " + e.getMessage());
        }
    }
}

import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EmployeeManagerGUI {
    private static List<String[]> employeeList = new ArrayList<>();
    private static DefaultTableModel tableModel;
    private static JTable table;
    private static final String csvPath = "/Users/mikeegutierrezmiguel/MOTORPH DATA FILES/MotorPH Employee Data - Employee Details.csv";

    public static void main(String[] args) {
        JFrame frame = new JFrame("MotorPH Employee Records");
        frame.setSize(1050, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        String[] columnNames = {"Emp #", "Last Name", "First Name", "SSS", "Philhealth", "TIN", "Pag-ibig"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 1000, 200);

        loadEmployeeDataFromCSV();

        // Buttons
        JButton viewBtn = new JButton("View Employee");
        JButton addBtn = new JButton("Add Employee");
        JButton updateBtn = new JButton("Update Employee");
        JButton deleteBtn = new JButton("Delete Employee");

        viewBtn.setBounds(20, 240, 150, 30);
        addBtn.setBounds(190, 240, 150, 30);
        updateBtn.setBounds(360, 240, 150, 30);
        deleteBtn.setBounds(530, 240, 150, 30);

        // View
        viewBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected >= 0) {
                String[] emp = employeeList.get(selected);
                JOptionPane.showMessageDialog(frame, String.join("\n",
                        "Employee #: " + emp[0],
                        "Name: " + emp[2] + " " + emp[1],
                        "SSS: " + emp[3],
                        "PhilHealth: " + emp[4],
                        "TIN: " + emp[5],
                        "Pag-ibig: " + emp[6]));
            } else {
                JOptionPane.showMessageDialog(frame, "Select an employee first.");
            }
        });

        // Add
        addBtn.addActionListener(e -> showEmployeeDialog(frame, false));

        // Update
        updateBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected >= 0) {
                showEmployeeDialog(frame, true);
            } else {
                JOptionPane.showMessageDialog(frame, "Please select an employee to update.");
            }
        });

        // Delete
        deleteBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected >= 0) {
                int confirm = JOptionPane.showConfirmDialog(frame,
                        "Are you sure you want to delete this employee?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    employeeList.remove(selected);
                    tableModel.removeRow(selected);
                    saveToCSV();
                    JOptionPane.showMessageDialog(frame, "Employee deleted successfully.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please select an employee to delete.");
            }
        });

        // UI Layout
        frame.add(scrollPane);
        frame.add(viewBtn);
        frame.add(addBtn);
        frame.add(updateBtn);
        frame.add(deleteBtn);
        frame.setVisible(true);
    }

    private static void showEmployeeDialog(JFrame parent, boolean isUpdate) {
        JTextField idField = new JTextField();
        JTextField lastField = new JTextField();
        JTextField firstField = new JTextField();
        JTextField sssField = new JTextField();
        JTextField philField = new JTextField();
        JTextField tinField = new JTextField();
        JTextField pagField = new JTextField();

        JPanel panel = new JPanel(new java.awt.GridLayout(0, 1));
        panel.add(new JLabel("Employee #:")); panel.add(idField);
        panel.add(new JLabel("Last Name:")); panel.add(lastField);
        panel.add(new JLabel("First Name:")); panel.add(firstField);
        panel.add(new JLabel("SSS #:")); panel.add(sssField);
        panel.add(new JLabel("PhilHealth #:")); panel.add(philField);
        panel.add(new JLabel("TIN #:")); panel.add(tinField);
        panel.add(new JLabel("Pag-ibig #:")); panel.add(pagField);

        int selected = table.getSelectedRow();
        if (isUpdate && selected >= 0) {
            String[] emp = employeeList.get(selected);
            idField.setText(emp[0]);
            lastField.setText(emp[1]);
            firstField.setText(emp[2]);
            sssField.setText(emp[3]);
            philField.setText(emp[4]);
            tinField.setText(emp[5]);
            pagField.setText(emp[6]);
        }

        int result = JOptionPane.showConfirmDialog(parent, panel,
                isUpdate ? "Update Employee" : "Add New Employee",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String[] emp = {
                idField.getText(),
                lastField.getText(),
                firstField.getText(),
                sssField.getText(),
                philField.getText(),
                tinField.getText(),
                pagField.getText()
            };

            if (isUpdate) {
                employeeList.set(selected, emp);
                for (int i = 0; i < emp.length; i++) {
                    tableModel.setValueAt(emp[i], selected, i);
                }
                JOptionPane.showMessageDialog(parent, "Employee updated successfully.");
            } else {
                employeeList.add(emp);
                tableModel.addRow(emp);
                JOptionPane.showMessageDialog(parent, "New employee added successfully.");
            }

            saveToCSV();
        }
    }

    private static void loadEmployeeDataFromCSV() {
        try (BufferedReader br = new BufferedReader(new FileReader(csvPath))) {
            String line;
            br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",", -1);
                if (data.length >= 7) {
                    employeeList.add(data);
                    tableModel.addRow(data);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading CSV: " + e.getMessage());
        }
    }

    private static void saveToCSV() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(csvPath))) {
            pw.println("Emp #,Last Name,First Name,SSS,Philhealth,TIN,Pag-ibig");
            for (String[] emp : employeeList) {
                pw.println(String.join(",", emp));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving CSV: " + e.getMessage());
        }
    }
}

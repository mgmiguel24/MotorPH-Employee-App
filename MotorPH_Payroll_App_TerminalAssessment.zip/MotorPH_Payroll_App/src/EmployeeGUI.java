import java.io.*;
import java.time.LocalDate;
import java.util.*;
import javax.swing.*;

public class EmployeeGUI {
    public static void launch() {
        main(new String[0]);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MotorPH Employee Payroll");
        JLabel labelEmp = new JLabel("Select Employee:");
        JComboBox<String> comboBox = new JComboBox<>();
        JLabel labelDays = new JLabel("Enter Days Worked:");
        JTextField textDays = new JTextField();
        JButton computeButton = new JButton("Compute Net Pay");

        List<Employee> employees = loadEmployeesFromCSV();

        for (Employee emp : employees) {
            comboBox.addItem(emp.getEmployeeId() + " - " + emp.getFullName());
        }

        // Layout
        labelEmp.setBounds(30, 30, 200, 30);
        comboBox.setBounds(30, 60, 300, 30);
        labelDays.setBounds(30, 100, 200, 30);
        textDays.setBounds(30, 130, 300, 30);
        computeButton.setBounds(30, 180, 200, 30);

        computeButton.addActionListener(e -> {
            int index = comboBox.getSelectedIndex();
            if (index == -1) {
                JOptionPane.showMessageDialog(frame, "Please select an employee.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String daysInput = textDays.getText().trim();
            int daysWorked = 0;
            try {
                daysWorked = Integer.parseInt(daysInput);
                if (daysWorked < 0 || daysWorked > 31) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid number of days (0–31).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Employee selected = employees.get(index);
            double dailyRate = selected.getBasicSalary() / 21.0;
            double gross = dailyRate * daysWorked;
            double totalDeductions = 450 + 300 + 100 + 700;
            double netPay = gross - totalDeductions;

            JOptionPane.showMessageDialog(frame,
                    "Name: " + selected.getFullName() +
                            "\nPosition: " + selected.getPosition() +
                            "\nDays Worked: " + daysWorked +
                            "\nDaily Rate: ₱" + String.format("%.2f", dailyRate) +
                            "\nNet Pay: ₱" + String.format("%.2f", netPay));
        });

        frame.add(labelEmp);
        frame.add(comboBox);
        frame.add(labelDays);
        frame.add(textDays);
        frame.add(computeButton);
        frame.setSize(400, 320);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private static List<Employee> loadEmployeesFromCSV() {
        List<Employee> list = new ArrayList<>();
        String path = "/Users/mikeegutierrezmiguel/MOTORPH DATA FILES/MotorPH Employee Data - Employee Details.csv";

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            br.readLine(); // Skip header
            while ((line = br.readLine()) != null) {
                String[] row = line.split(",", -1);
                if (row.length >= 19) {
                    int empId = Integer.parseInt(row[0].replaceAll("[^\\d]", ""));
                    String last = row[1];
                    String first = row[2];
                    LocalDate birth = LocalDate.parse(formatDate(row[3]));
                    String address = row[4];
                    String phone = row[5];
                    String sss = row[6];
                    String phil = row[7];
                    String tin = row[8];
                    String pag = row[9];
                    String status = row[10];
                    String pos = row[11];
                    String supervisor = row[12];
                    double basic = parseDouble(row[13]);
                    double rice = parseDouble(row[14]);
                    double phoneAll = parseDouble(row[15]);
                    double cloth = parseDouble(row[16]);

                    Employee emp = new Employee(empId, first, last, birth, address, phone,
                            sss, phil, tin, pag, status, pos, "Department", supervisor,
                            basic, rice, phoneAll, cloth);
                    list.add(emp);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading CSV:\n" + e.getMessage());
        }

        return list;
    }

    private static double parseDouble(String s) {
        return Double.parseDouble(s.replaceAll("[^\\d.]", ""));
    }

    private static String formatDate(String d) {
        String[] parts = d.trim().split("/");
        if (parts.length == 3) {
            return String.format("%s-%02d-%02d", parts[2], Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
        }
        return "2000-01-01";
    }
}

import java.io.*;
import javax.swing.*;

public class LoginScreen {

    public static void main(String[] args) {
        JFrame frame = new JFrame("MotorPH Login");
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        JTextField userField = new JTextField();
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField();
        JButton loginBtn = new JButton("Login");

        userLabel.setBounds(30, 20, 100, 25);
        userField.setBounds(120, 20, 180, 25);
        passLabel.setBounds(30, 60, 100, 25);
        passField.setBounds(120, 60, 180, 25);
        loginBtn.setBounds(120, 100, 100, 30);

        loginBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            if (checkCredentials(username, password)) {
                JOptionPane.showMessageDialog(frame, "Login successful!");
                frame.dispose();
                EmployeeManagerGUI.main(null); // Launch main app
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid credentials. Try again.");
            }
        });

        frame.add(userLabel);
        frame.add(userField);
        frame.add(passLabel);
        frame.add(passField);
        frame.add(loginBtn);
        frame.setVisible(true);
    }

    private static boolean checkCredentials(String username, String password) {
        String path = "/Users/mikeegutierrezmiguel/MOTORPH DATA FILES/login_credentials - Sheet1.csv";
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2 &&
                    parts[0].trim().equals(username) &&
                    parts[1].trim().equals(password)) {
                    return true;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading login CSV file:\n" + e.getMessage());
        }
        return false;
    }
}

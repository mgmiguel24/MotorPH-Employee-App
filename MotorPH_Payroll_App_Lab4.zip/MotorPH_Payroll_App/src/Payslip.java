import java.time.LocalDate;

/**
 * Represents a payslip for an employee for a specific pay period.
 */
public class Payslip {
    // Attributes
    private int payslipId;
    private Employee employee;
    private LocalDate periodStart;
    private LocalDate periodEnd;
    private double daysWorked;
    private double overtimeHours;
    private double grossIncome;
    private double totalBenefits;
    private Deduction deduction;
    private double netIncome;

    // Constructors
    /** No-argument constructor. */
    public Payslip() {
        // Default constructor
    }

    /**
     * Parameterized constructor to initialize all Payslip attributes.
     */
    public Payslip(int payslipId, Employee employee, LocalDate periodStart, LocalDate periodEnd,
                   double daysWorked, double overtimeHours, double grossIncome,
                   double totalBenefits, Deduction deduction, double netIncome) {
        this.payslipId = payslipId;
        this.employee = employee;
        this.periodStart = periodStart;
        this.periodEnd = periodEnd;
        this.daysWorked = daysWorked;
        this.overtimeHours = overtimeHours;
        this.grossIncome = grossIncome;
        this.totalBenefits = totalBenefits;
        this.deduction = deduction;
        this.netIncome = netIncome;
    }

    // Getters and Setters
    public int getPayslipId() {
        return payslipId;
    }
    public void setPayslipId(int payslipId) {
        this.payslipId = payslipId;
    }

    public Employee getEmployee() {
        return employee;
    }
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public LocalDate getPeriodStart() {
        return periodStart;
    }
    public void setPeriodStart(LocalDate periodStart) {
        this.periodStart = periodStart;
    }

    public LocalDate getPeriodEnd() {
        return periodEnd;
    }
    public void setPeriodEnd(LocalDate periodEnd) {
        this.periodEnd = periodEnd;
    }

    public double getDaysWorked() {
        return daysWorked;
    }
    public void setDaysWorked(double daysWorked) {
        this.daysWorked = daysWorked;
    }

    public double getOvertimeHours() {
        return overtimeHours;
    }
    public void setOvertimeHours(double overtimeHours) {
        this.overtimeHours = overtimeHours;
    }

    public double getGrossIncome() {
        return grossIncome;
    }
    public void setGrossIncome(double grossIncome) {
        this.grossIncome = grossIncome;
    }

    public double getTotalBenefits() {
        return totalBenefits;
    }
    public void setTotalBenefits(double totalBenefits) {
        this.totalBenefits = totalBenefits;
    }

    public Deduction getDeduction() {
        return deduction;
    }
    public void setDeduction(Deduction deduction) {
        this.deduction = deduction;
    }

    public double getNetIncome() {
        return netIncome;
    }
    public void setNetIncome(double netIncome) {
        this.netIncome = netIncome;
    }

    // (No additional methods in Payslip; it's mainly a data holder for now)
}

import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EmployeeManagerGUI {
    private static List<String[]> employeeList = new ArrayList<>();
    private static DefaultTableModel tableModel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("MotorPH Employee Records");
        frame.setSize(1000, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        String[] columnNames = {"Emp #", "Last Name", "First Name", "SSS", "Philhealth", "TIN", "Pag-ibig"};
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 950, 200);

        // Load from CSV file
        loadEmployeeDataFromCSV("/Users/mikeegutierrezmiguel/MOTORPH DATA FILES/MotorPH Employee Data - Employee Details.csv");

        // View button
        JButton viewBtn = new JButton("View Employee");
        viewBtn.setBounds(20, 240, 150, 30);
        viewBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected >= 0) {
                String[] emp = employeeList.get(selected);
                JOptionPane.showMessageDialog(frame, String.join("\n",
                        "Employee #: " + emp[0],
                        "Name: " + emp[2] + " " + emp[1],
                        "SSS: " + emp[3],
                        "PhilHealth: " + emp[4],
                        "TIN: " + emp[5],
                        "Pag-ibig: " + emp[6]));
            } else {
                JOptionPane.showMessageDialog(frame, "Select an employee first.");
            }
        });

        // Add new employee
        JButton addBtn = new JButton("Add Employee");
        addBtn.setBounds(190, 240, 150, 30);
        addBtn.addActionListener(e -> showAddEmployeeDialog(frame));

        frame.add(scrollPane);
        frame.add(viewBtn);
        frame.add(addBtn);
        frame.setVisible(true);
    }

    private static void loadEmployeeDataFromCSV(String csvPath) {
        try (BufferedReader br = new BufferedReader(new FileReader(csvPath))) {
            String line;
            br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",", -1);
                if (data.length >= 7) {
                    employeeList.add(data);
                    tableModel.addRow(data);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading CSV: " + e.getMessage());
        }
    }

    private static void showAddEmployeeDialog(JFrame parent) {
        JTextField idField = new JTextField();
        JTextField lastField = new JTextField();
        JTextField firstField = new JTextField();
        JTextField sssField = new JTextField();
        JTextField philField = new JTextField();
        JTextField tinField = new JTextField();
        JTextField pagField = new JTextField();

        JPanel panel = new JPanel(new java.awt.GridLayout(0, 1));
        panel.add(new JLabel("Employee #:")); panel.add(idField);
        panel.add(new JLabel("Last Name:")); panel.add(lastField);
        panel.add(new JLabel("First Name:")); panel.add(firstField);
        panel.add(new JLabel("SSS #:")); panel.add(sssField);
        panel.add(new JLabel("PhilHealth #:")); panel.add(philField);
        panel.add(new JLabel("TIN #:")); panel.add(tinField);
        panel.add(new JLabel("Pag-ibig #:")); panel.add(pagField);

        int result = JOptionPane.showConfirmDialog(parent, panel, "Add New Employee",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String[] newEmp = {
                idField.getText(),
                lastField.getText(),
                firstField.getText(),
                sssField.getText(),
                philField.getText(),
                tinField.getText(),
                pagField.getText()
            };
            employeeList.add(newEmp);
            tableModel.addRow(newEmp);
            saveToCSV("/Users/mikeegutierrezmiguel/MOTORPH DATA FILES/MotorPH Employee Data - Employee Details.csv");
            JOptionPane.showMessageDialog(parent, "New employee added and saved.");
        }
    }

    private static void saveToCSV(String csvPath) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(csvPath))) {
            pw.println("Emp #,Last Name,First Name,SSS,Philhealth,TIN,Pag-ibig");
            for (String[] emp : employeeList) {
                pw.println(String.join(",", emp));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

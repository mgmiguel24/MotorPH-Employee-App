import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

public class EmployeeManagerGUI {
    public static void main(String[] args) {
        // Create a window
        JFrame frame = new JFrame("Employee Records");

        // Column titles (like headers in Excel)
        String[] columnNames = {
            "Employee No", "Last Name", "First Name", "SSS", "PhilHealth", "TIN", "Pag-IBIG"
        };

        // Employee data (you can add more later)
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(
            10001, "Manuel III", "Garcia",
            java.time.LocalDate.of(1983, 10, 11),
            "Valero Bldg", "966-860-270", "44-4506057-3", "820126853951",
            "598-065-761-000", "691295330870", "Regular", "CEO", "Leadership", "N/A",
            90000, 1500, 2000, 1000
        ));

        // Add employee data to the table
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (Employee emp : employees) {
            Object[] row = {
                emp.getEmployeeId(),
                emp.getLastName(),
                emp.getFirstName(),
                emp.getSssNumber(),
                emp.getPhilHealthNumber(),
                emp.getTin(),
                emp.getPagIbigNumber()
            };
            model.addRow(row);
        }

        // Create table and scroll bar
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Show everything in the window
        frame.add(scrollPane);
        frame.setSize(800, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}



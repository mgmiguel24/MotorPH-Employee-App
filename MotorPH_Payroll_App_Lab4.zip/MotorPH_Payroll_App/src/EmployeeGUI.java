import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("MotorPH Employee Payroll");
        JLabel labelEmp = new JLabel("Select Employee:");
        JComboBox<String> comboBox = new JComboBox<>();
        JLabel labelDays = new JLabel("Enter Days Worked:");
        JTextField textDays = new JTextField();
        JButton computeButton = new JButton("Compute Net Pay");

        // Real employee object
        List<Employee> employees = new ArrayList<>();
        Employee emp1 = new Employee(
            10001, "Manuel III", "Garcia",
            java.time.LocalDate.of(1983, 10, 11),
            "Valero Carpark Building Valero Street 1227, Makati City",
            "966-860-270", "44-4506057-3", "820126853951",
            "598-065-761-000", "691295330870", "Regular",
            "Chief Executive Officer", "Leadership", "N/A",
            90000.00, 1500.00, 2000.00, 1000.00
        );
        employees.add(emp1);

        for (Employee emp : employees) {
            comboBox.addItem(emp.getEmployeeId() + " - " + emp.getFullName());
        }

        // Layout
        labelEmp.setBounds(30, 30, 200, 30);
        comboBox.setBounds(30, 60, 300, 30);
        labelDays.setBounds(30, 100, 200, 30);
        textDays.setBounds(30, 130, 300, 30);
        computeButton.setBounds(30, 180, 200, 30);

        computeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int index = comboBox.getSelectedIndex();
                if (index == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select an employee.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String daysInput = textDays.getText().trim();
                int daysWorked = 0;
                try {
                    daysWorked = Integer.parseInt(daysInput);
                    if (daysWorked < 0 || daysWorked > 31) throw new NumberFormatException();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid number of days (0–31).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Employee selected = employees.get(index);
                double dailyRate = selected.getBasicSalary() / 21.0; // Updated divisor here
                double gross = dailyRate * daysWorked;
                double totalDeductions = 450 + 300 + 100 + 700; // sample fixed values
                double netPay = gross - totalDeductions;

                JOptionPane.showMessageDialog(frame,
                    "Name: " + selected.getFullName() +
                    "\nPosition: " + selected.getPosition() +
                    "\nDays Worked: " + daysWorked +
                    "\nDaily Rate: ₱" + String.format("%.2f", dailyRate) +
                    "\nNet Pay: ₱" + String.format("%.2f", netPay));
            }
        });

        frame.add(labelEmp);
        frame.add(comboBox);
        frame.add(labelDays);
        frame.add(textDays);
        frame.add(computeButton);
        frame.setSize(400, 320);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

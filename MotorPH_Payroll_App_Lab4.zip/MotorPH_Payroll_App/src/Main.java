import java.time.LocalDate;
import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {
        // EMPLOYEE DATA (from MotorPH Employee Data.xlsx)
        Employee emp = new Employee(
            10001,
            "Manuel III",
            "Garcia",
            LocalDate.of(1983, 10, 11),
            "Valero Carpark Building Valero Street 1227, Makati City",
            "966-860-270",
            "44-4506057-3",
            "820126853951",
            "598-065-761-000",
            "691295330870",
            "Regular",
            "Chief Executive Officer",
            "Leadership",
            "N/A",
            90000.00,
            1500.00,
            2000.00,
            1000.00
        );

        // ATTENDANCE (sample date and time)
        Attendance att = new Attendance(emp, LocalDate.of(2024, 6, 3),
                                        LocalTime.of(8, 59), LocalTime.of(18, 31));
        double hoursWorked = att.calculateHours();
        System.out.println("Hours worked on " + att.getDate() + ": " + hoursWorked);

        // DEDUCTION (sample values from school table)
        Deduction ded = new Deduction(450.00, 300.00, 100.00, 700.00);

        // PAYROLL CALCULATOR (logic not implemented yet)
        PayrollCalculator calc = new PayrollCalculator();
        double grossPay = calc.calculateGrossIncome(emp, 10, 5);
        double benefits = calc.calculateTotalBenefits(emp);
        double totalDeductions = ded.getTotalDeductions();
        double netPay = calc.calculateNetIncome(grossPay, benefits, totalDeductions);

        // PAYSLIP
        Payslip payslip = new Payslip(
            1,
            emp,
            LocalDate.of(2024, 6, 1),
            LocalDate.of(2024, 6, 15),
            10,
            5,
            grossPay,
            benefits,
            ded,
            netPay
        );
        System.out.println("Payslip " + payslip.getPayslipId() + " for " 
                           + emp.getFullName() + ": Net Income = " + netPay);

        // PAYROLL SUMMARY
        PayrollSummaryReport report = new PayrollSummaryReport();
        report.addEmployee(emp);
        report.generateReport();
        System.out.println("Total employees in report: " + report.getEmployees().size());
        System.out.println("Total Net Income (all employees): " + report.getTotalNetIncome());
    }
}

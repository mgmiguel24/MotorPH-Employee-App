import java.util.ArrayList;
import java.util.List;

/**
 * Represents a payroll summary report for a set of employees over a period (e.g., monthly report).
 * It contains a list of employees and aggregated totals for salaries and deductions.
 */
public class PayrollSummaryReport {
    // Attributes
    private List<Employee> employees;
    private double totalSalary;
    private double totalSSSContribution;
    private double totalPhilHealthContribution;
    private double totalPagIbigContribution;
    private double totalWithholdingTax;
    private double totalNetIncome;

    // Constructors
    /** No-argument constructor that initializes the employee list. */
    public PayrollSummaryReport() {
        this.employees = new ArrayList<>();
        // Totals will be calculated when generateReport() is implemented
    }

    /**
     * (Optional) Parameterized constructor to initialize report with a given list of employees.
     */
    public PayrollSummaryReport(List<Employee> employees) {
        this.employees = employees;
        // We could initialize totals here, but will defer to generateReport()
    }

    // Getters and Setters
    public List<Employee> getEmployees() {
        return employees;
    }
    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public double getTotalSalary() {
        return totalSalary;
    }
    public void setTotalSalary(double totalSalary) {
        this.totalSalary = totalSalary;
    }

    public double getTotalSSSContribution() {
        return totalSSSContribution;
    }
    public void setTotalSSSContribution(double totalSSSContribution) {
        this.totalSSSContribution = totalSSSContribution;
    }

    public double getTotalPhilHealthContribution() {
        return totalPhilHealthContribution;
    }
    public void setTotalPhilHealthContribution(double totalPhilHealthContribution) {
        this.totalPhilHealthContribution = totalPhilHealthContribution;
    }

    public double getTotalPagIbigContribution() {
        return totalPagIbigContribution;
    }
    public void setTotalPagIbigContribution(double totalPagIbigContribution) {
        this.totalPagIbigContribution = totalPagIbigContribution;
    }

    public double getTotalWithholdingTax() {
        return totalWithholdingTax;
    }
    public void setTotalWithholdingTax(double totalWithholdingTax) {
        this.totalWithholdingTax = totalWithholdingTax;
    }

    public double getTotalNetIncome() {
        return totalNetIncome;
    }
    public void setTotalNetIncome(double totalNetIncome) {
        this.totalNetIncome = totalNetIncome;
    }

    // Other Methods
    /**
     * Adds an employee to the report.
     */
    public void addEmployee(Employee employee) {
        this.employees.add(employee);
    }

    /**
     * Generates the summary report by calculating total values for salary, deductions, and net income.
     * (Currently a placeholder with no implementation.)
     */
    public void generateReport() {
        // TODO: Implement logic to calculate totals for all employees in the list.
        // This would sum up each employee's salary, contributions, and net income.
        // For now, this method does not perform any calculations.
    }
}

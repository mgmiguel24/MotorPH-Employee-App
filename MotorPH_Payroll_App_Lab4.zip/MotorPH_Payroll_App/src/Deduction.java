/**
 * Represents the various deductions for an employee (e.g., SSS, PhilHealth, Pag-IBIG, Tax).
 */
public class Deduction {
    // Attributes
    private double sssContribution;
    private double philHealthContribution;
    private double pagIbigContribution;
    private double withholdingTax;

    // Constructors
    /** No-argument constructor. */
    public Deduction() {
        // Default constructor
    }

    /**
     * Parameterized constructor to initialize all Deduction attributes.
     */
    public Deduction(double sssContribution, double philHealthContribution,
                     double pagIbigContribution, double withholdingTax) {
        this.sssContribution = sssContribution;
        this.philHealthContribution = philHealthContribution;
        this.pagIbigContribution = pagIbigContribution;
        this.withholdingTax = withholdingTax;
    }

    // Getters and Setters
    public double getSssContribution() {
        return sssContribution;
    }
    public void setSssContribution(double sssContribution) {
        this.sssContribution = sssContribution;
    }

    public double getPhilHealthContribution() {
        return philHealthContribution;
    }
    public void setPhilHealthContribution(double philHealthContribution) {
        this.philHealthContribution = philHealthContribution;
    }

    public double getPagIbigContribution() {
        return pagIbigContribution;
    }
    public void setPagIbigContribution(double pagIbigContribution) {
        this.pagIbigContribution = pagIbigContribution;
    }

    public double getWithholdingTax() {
        return withholdingTax;
    }
    public void setWithholdingTax(double withholdingTax) {
        this.withholdingTax = withholdingTax;
    }

    // Other Methods
    /**
     * Calculates the total deductions by summing all deduction fields.
     */
    public double getTotalDeductions() {
        // Sum up all contributions and taxes
        return sssContribution + philHealthContribution + pagIbigContribution + withholdingTax;
    }
}

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Represents an attendance record for a given employee on a specific date.
 */
public class Attendance {
    // Attributes
    private Employee employee;
    private LocalDate date;
    private LocalTime loginTime;
    private LocalTime logoutTime;

    // Constructors
    /** No-argument constructor. */
    public Attendance() {
        // Default constructor
    }

    /**
     * Parameterized constructor to initialize all Attendance attributes.
     */
    public Attendance(Employee employee, LocalDate date, LocalTime loginTime, LocalTime logoutTime) {
        this.employee = employee;
        this.date = date;
        this.loginTime = loginTime;
        this.logoutTime = logoutTime;
    }

    // Getters and Setters
    public Employee getEmployee() {
        return employee;
    }
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public LocalDate getDate() {
        return date;
    }
    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getLoginTime() {
        return loginTime;
    }
    public void setLoginTime(LocalTime loginTime) {
        this.loginTime = loginTime;
    }

    public LocalTime getLogoutTime() {
        return logoutTime;
    }
    public void setLogoutTime(LocalTime logoutTime) {
        this.logoutTime = logoutTime;
    }

    // Other Methods
    /**
     * Calculates the total hours worked based on login and logout times.
     * (No implementation yet; will compute duration between loginTime and logoutTime.)
     */
    public double calculateHours() {
        // TODO: Implement calculation of hours worked (currently returns 0 by default)
        return 0;
    }
}
